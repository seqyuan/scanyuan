pypi
=================

https://pypi.org/project/scanyuan/

wiki
=================

https://github.com/seqyuan/scanyuan/wiki

Install scanyuan
=================
安装示例
::

    pip3 install scanyuan

class
=================

::


::


                
::


