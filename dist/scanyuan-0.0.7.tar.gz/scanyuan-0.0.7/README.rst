pypi
=================

https://pypi.org/project/scanyuan/

github
=================

https://github.com/seqyuan/scanyuan

Install scanyuan
=================
安装示例
::

    pip3 install scanyuan

class
=================

::


::


                
::


